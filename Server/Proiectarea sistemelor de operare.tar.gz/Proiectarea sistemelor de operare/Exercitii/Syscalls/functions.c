#define _GNU_SOURCE
#include <stdlib.h>
#include <stdarg.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>

int gok=0;

int open(const char *__file, int __oflag, ...)
{

    va_list args;
    mode_t mode=0;

    if(__oflag & O_CREAT)
    {
        va_start(args, __oflag);
        mode=va_arg(args, mode_t);
        va_end(args);

    }

    int (*real_open1)(const char*, int, mode_t)=dlsym(RTLD_NEXT, "open");
    int (*real_open2)(const char*, int)=dlsym(RTLD_NEXT, "open");
    int ok;

    if(__oflag & O_CREAT)
        ok=real_open1(__file, __oflag, mode);
    else 
        ok=real_open2(__file, __oflag);

    if(ok>=0)
        printf("Fisierul %s a fost deschis.\n", __file);
    else
        printf("Eroarela sdeschiderea fisierului %s.\n", __file);
   
    return ok;
}

ssize_t read(int __fd, void *__buf, size_t __nbytes)
{
    ssize_t (*real_read)(int, void*, size_t)=dlsym(RTLD_NEXT, "read");

    int bytes=real_read(__fd, __buf, __nbytes);
    printf("Au fost cititi %d bytes.\n", bytes);

    return bytes;
}

ssize_t write(int __fd, const void *__buf, size_t __n)
{
    ssize_t (*real_write)(int, const void*, size_t)=dlsym(RTLD_NEXT, "write");

    int bytes=real_write(__fd, __buf, __n);
    printf("Au fost scrisi %d bytes.\n", bytes);

    return bytes;
}

int close(int __fd)
{
    int (*real_close)(int)=dlsym(RTLD_NEXT, "close");

    int ok=real_close(__fd);

    if(ok==0)
        printf("Fisierul a fost inchis.\n");
    else
        printf("Eroare la inchiderea fisierului.\n");
        
    return ok;
}






