#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>


int main()
{
    int fd=open("file.txt", O_RDONLY);
    if(fd<0)
    {
        printf("eroare la deschiderea fisierului file.txt.\n");
        exit(1);
    }

    char* buff=(char*)malloc(255);
    if(buff==NULL)
    {
        printf("Eroare alocare.\n");
        exit(1);
    }


    int bytes=0;
    do
    {
        bytes=read(fd, buff, 255);
        write(STDOUT_FILENO, buff, bytes);
    } while (bytes>0);

    if(close(fd)!=0)
    {
        printf("Eroare la inchiderea fisierului file.txt.\n");
        exit(1);
    }
    

    return 0;
}
