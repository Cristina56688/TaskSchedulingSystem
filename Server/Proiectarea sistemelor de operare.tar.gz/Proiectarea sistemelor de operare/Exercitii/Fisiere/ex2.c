#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>


int main(int argc, char** argv)
{
    if(argc<2)
    {
        printf("Prea putine argumente.\n");
        exit(1);
    }

    struct stat info;

    if(lstat(argv[1], &info)==-1)
    {
        printf("Eroare la stat.\n");
        exit(1);
    }

    if(S_ISLNK(info.st_mode))
    {
        printf("Fisierul este link simbolic.\n");
        exit(1);
    }

    int fd=open(argv[1], S_IRUSR);
    if(fd<0)
    {
        printf("Eroare la deschiderea fisieerului.\n");
        exit(1);
    }

    lseek(fd, -20, SEEK_END);
    char* buff=(char*)malloc(20*sizeof(char));

    int bytes=read(fd, buff, 20);
    write(STDOUT_FILENO, buff, bytes);

    if(close(fd)!=0)
    {
        printf("Eroare la inchiderea fisierului\n");
        exit(1);
    }


    return 0;
}