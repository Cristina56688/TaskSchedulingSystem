#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>

int get_permisions(char* perm)
{
    int mode = 0;

    for (int i = 0; i < 9; i += 3)
    {
        int val = 0;

        if (perm[i] == 'r') val += 4;
        if (perm[i + 1] == 'w') val += 2;
        if (perm[i + 2] == 'x') val += 1;

        mode = (mode << 3) | val;
    }

    return mode;
}

int main(int argc, char** argv)
{
    if(argc!= 3)
    {
        printf("Nu au fost setate 2 argumente.\n");
        exit(1);
    }

    int fd=open(argv[1], S_IRUSR);
    if(fd>=0)
    {
        printf("Fisierul exista deja.\n");
        exit(1);
    }

    umask(0);
    fd=open(argv[1], O_CREAT, get_permisions(argv[2]));
    if(fd<=0)
    {
        printf("Eroare la crearea fisierului.\n");
        exit(1);
    }

    if(close(fd)!=0)
    {
        printf("Eroare la inchiderea fisierului.\n");
        exit(1);
    }

    return 0;
}