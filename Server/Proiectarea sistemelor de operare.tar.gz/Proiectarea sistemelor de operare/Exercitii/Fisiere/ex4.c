#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <time.h>
#include <fcntl.h>

char* get_random_buff(int n)
{
    char* buff=(char*)malloc(n*sizeof(char));

    srand(time(NULL));
    for(int i=0; i<n; i++)
        buff[i]='a'+rand()%26;
        
    return buff;
}

int main(int argc, char** argv)
{
    if(argc!=2)
    {
        printf("Functia trebuie sa primeasca un argument.\n");
        exit(1);
    }

    int fd=open(argv[1], O_WRONLY);
    if(fd>=0)
    {
        int lenght=lseek(fd, 0, SEEK_END);
        lseek(fd, 0, SEEK_SET);
        if(lenght>10)
            ftruncate(fd, 10);
    }
    else
    {
        fd=open(argv[1], O_CREAT | O_WRONLY, S_IRWXU);
        if(fd<0)
        {
            printf("Eroare la crearea fisierului.\n");
            exit(1);
        }

        char* buff=get_random_buff(10);
        write(fd, buff, 10);

    }

    if(close(fd)!=0)
    {
        printf("Eroare la inchiderea fisierului.\n");
        exit(1);
    }

    return 0;
}

