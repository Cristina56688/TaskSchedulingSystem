#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

int main(int argc, char** argv)
{
    if(argc!=2)
    {
        printf("Programul trebuie sa primeasca un argument.\n");
        exit(1);
    }

    int fd=open(argv[1], O_RDWR | O_APPEND);
    if(fd<0)
    {
        printf("Eroare la deschiderea fisierului.\n");
        exit(1);
    }

    char* buff=(char*)malloc(1024);
    if(buff==NULL)
    {
        printf("Eroare la alocare.\n");
        exit(1);
    }

    int bytes=read(fd, buff, 1024);

    if(fcntl(fd, F_SETFL, __O_NOATIME)!=0)
    {
        printf("Eroare in setarea flag-ului.\n");
        exit(1);
    }

    write(fd, buff, bytes);

        if(close(fd)!=0)
    {
        printf("Eroare la inchiderea fisierului.\n");
        exit(1);
    }

    return 0;
}