#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>

#define DIE(assertion, call_description) \
    do { \
        if (assertion) { \
            perror(call_description); \
            exit(EXIT_FAILURE); \
        } \
    } while (0)

#endif 
