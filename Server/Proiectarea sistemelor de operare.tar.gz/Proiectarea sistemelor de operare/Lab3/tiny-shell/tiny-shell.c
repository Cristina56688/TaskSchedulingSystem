#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/unistd.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>

#define READ_END 0
#define WRITE_END 1

char* get_line();
char** parse_line(char* line, char* const* envp);
bool find_red(char** command);
bool find_pipe(char** command);
void redirect_command(char** command, char* const* envp);
void pipe_command(char** command, char* const* envp);
void simple_cmd(char** command, char* const* envp);

char* get_line()
{
    char* str=(char*)malloc(255*sizeof(char));
    if(str==NULL)
    {
        write(STDOUT_FILENO, "Eroare alocare.\n", 16);
        exit(1);
    }

    read(STDIN_FILENO, str, 255);
    return str;
}

char** parse_line(char* line, char* const* envp)
{
    char** command=(char**)malloc(12*sizeof(char*));
        if(command==NULL)
    {
        write(STDOUT_FILENO, "Eroare alocare.\n", 16);
        exit(1);
    }

    for(int i=0; i<12; i++)
    {
        command[i]=(char*)malloc(20);
            if(command[i]==NULL)
            {
                write(STDOUT_FILENO, "Eroare alocare.\n", 16);
                exit(1);
            }
    }

    char* p=strtok(line, " ");
    int i=0;
    while(p)
    {
        if(strchr(p, '=')==NULL)
        {
        if(p[0]=='$')
           {
             p=getenv(p+1);
             if(p==NULL)
             {
                 write(STDOUT_FILENO, "Nu exista variabila de mediu.\n", 30);
                return NULL;
             }
            }
        strcpy(command[i], p);
        i++;
        }
        else 
        {
            char* var=strchr(p, '=')+1;
            p=p+1;
            p[strcspn(p, "=")]='\0';
            if(setenv(p, var, 1)==-1)
            {
                write(STDOUT_FILENO, "Eroare setenv.\n", 15);
                exit(1);
            }
        }

        p=strtok(NULL, " ");
    }
    command[i]=NULL;

    return command;
}


bool find_red(char** command)
{
    int i=0;
    while(command[i]!=NULL)
    {
        if(strcmp(command[i], ">")==0)
            return true;
        i++;
    }

    return false;
}

bool find_pipe(char** command)
{
    int i=0;
    while(command[i]!=NULL)
    {
        if(strcmp(command[i], "|")==0)
            return true;
        i++;
    }

    return false;
}



void redirect_command(char** command, char* const* envp)
{
    int i=0;
    while(command[i]!=NULL)
    {
        if(strcmp(command[i],">")==0) break;
        i++;
    }

    char* file=(char*)malloc(20);

    if(command[i+1]==NULL)
    {
        write(STDOUT_FILENO, "Lipsa fisier redirectare.\n", 26);
        return;
    }
    else strcpy(file, command[i+1]);

    command[i]=NULL;
    
    int fd=open(file, O_WRONLY | O_TRUNC | O_CREAT, S_IRWXU);
    if(fd<0)
    {
        write(STDOUT_FILENO, "Eroare fisier.\n", 15);
        exit(1);
    }

    int aux=dup(STDOUT_FILENO);
    if(aux==-1)
    {
        write(STDOUT_FILENO, "Eroare duplicare descriptor.\n", 29);
        exit(1);
    }

    if(dup2(fd, STDOUT_FILENO)==-1)
    {
        exit(1);
    }

    pid_t pid=fork();

    if(pid==0)
    {
        execvpe(command[0], command, envp);

        write(STDOUT_FILENO, "Eroare execpve.\n", 16);
        exit(1);
    }
    else if(pid>1)
    {
        wait(NULL);
    }
    else 
    {
        write(STDOUT_FILENO, "Eroare fork.\n", 13);
        exit(1);
    }

    if(dup2(aux, STDOUT_FILENO)==-1)
    {
        exit(1);
    }

    if(close(fd)==-1)
    {
        write(STDOUT_FILENO, "Eroare inchidere fisier.\n", 25);
        exit(1);
    }

    free(file);

}

void simple_cmd(char** command, char* const* envp)
{
    if(command==NULL)
    return;

    if(find_red(command))
        {
            redirect_command(command, envp);
            return;
        }

    if(find_pipe(command))
    {
        pipe_command(command, envp);
        return;
    }

    pid_t pid = fork();

    if (pid == 0) 
    {
        execvpe(command[0], command, envp);

        write(STDOUT_FILENO, "Eroare execpve.\n", 16);
        exit(1);
    } 
    else if (pid > 0)
    {
        wait(NULL);
    } 
    else 
    {
        write(STDOUT_FILENO, "Eroare fork.\n", 13);
        exit(1);
    }
}


void pipe_command(char** command, char* const* envp)
{
    int i=0;
    while(command[i]!=NULL)
    {
        if(strcmp(command[i],"|")==0) break;
        i++;
    }

    command[i]=NULL;

    int ret;
	int pipe_fd[2];
	
	ret = pipe(pipe_fd);
	if (ret < 0) {
		write(STDOUT_FILENO, "Eroare pipe.\n", 13);
		exit(-1);
    }

    pid_t p1 = fork();
    if (p1 == 0) {
        close(pipe_fd[READ_END]);
        dup2(pipe_fd[WRITE_END], STDOUT_FILENO);
        close(pipe_fd[WRITE_END]);

        execvpe(command[0], command, envp);
        exit(1);
    }

    pid_t p2 = fork();
    if (p2 == 0) {
        close(pipe_fd[WRITE_END]);
        dup2(pipe_fd[READ_END], STDIN_FILENO);
        close(pipe_fd[READ_END]);

        execvpe(command[i+1], command + i + 1, envp);
        exit(1);
    }

    close(pipe_fd[READ_END]);
    close(pipe_fd[WRITE_END]);
    waitpid(p1, NULL, 0);
    waitpid(p2, NULL, 0);
}


int main(int argc, const char** argv, char* const* envp)
{

    while(1) {

        printf("> ");
        setvbuf(stdout, NULL, _IONBF, 0);

        char *line = get_line();
        line[strcspn(line, "\n")]='\0';
        if(strcmp(line, "exit")==0)
            break;
        
        char **command = parse_line(line, envp);
        simple_cmd(command, envp);

        if(line!=NULL)
            free(line);
    }

    return 0;
}

