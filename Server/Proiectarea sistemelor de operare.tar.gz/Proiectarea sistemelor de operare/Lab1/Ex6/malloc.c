#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>

int pr=0;

void* malloc(size_t size) 
{

    void* (*real_malloc)(size_t) = dlsym(RTLD_NEXT, "malloc");

    void* p=real_malloc(size);
    if(pr==1) return p;

    if(p==NULL)
       {
         pr=1;
         printf("allocated 0 bytes\n");
       }
    else 
       {
        pr=1;
        printf ("allocated %d bytes at 0x%x\n", (int)size, (int)p);
       }

    pr=0;    
    return p;
}

void free(void* ptr) 
{
    void (*real_free)(size_t) = dlsym(RTLD_NEXT, "free");    

    pr=1;
    printf("free memory at %x\n", (int)ptr);
    real_free(ptr);
    pr=0;
}


