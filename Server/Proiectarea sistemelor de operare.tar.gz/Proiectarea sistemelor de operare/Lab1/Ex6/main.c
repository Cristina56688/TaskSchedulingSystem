#include "malloc.h"

int main()
{
    char* p=(char*)malloc(10*sizeof(char));
    char* v=(char*)malloc(10*sizeof(int));
    free(p);
    free(v);

    return 0;
}