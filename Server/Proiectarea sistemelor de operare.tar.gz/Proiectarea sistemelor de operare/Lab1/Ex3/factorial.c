
int factorial(int x)
{
    int r=1;
    while(x)
    {
        r*=x;
        x--;
    }

    return r;
}