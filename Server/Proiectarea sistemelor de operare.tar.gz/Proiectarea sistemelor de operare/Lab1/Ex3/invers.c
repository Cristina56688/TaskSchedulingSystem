#include <stdlib.h>

char* inversSir(char* sir, int l)
{
    char* inv=(char*)malloc(l+1);

    for(int i=0; i<l; i++)
        inv[l-1-i]=sir[i];
    inv[l]=0;

    return inv;
}