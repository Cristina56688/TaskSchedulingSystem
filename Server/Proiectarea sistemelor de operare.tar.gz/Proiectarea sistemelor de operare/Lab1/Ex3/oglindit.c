
int oglindit(int x)
{
    int o=0;
    while(x)
    {
        o=o*10+x%10;
        x/=10;
    }

    return o;
}