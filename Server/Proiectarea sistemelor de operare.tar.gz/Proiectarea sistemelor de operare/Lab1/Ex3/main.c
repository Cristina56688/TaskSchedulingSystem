#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "mylib.h"
 
#define NAME "student"
#define NR (10)
 
int main()
{
  int i;
 
  char* sir=(char*)malloc(4);
  strcpy(sir, "abc");

  printf("%d\n", oglindit(123));
  printf("%d\n", factorial(10));
  printf("%s\n", inversSir(sir, 3));
 
  return 0;
}