
int factorial(int x);
int oglindit(int x);
char* inversSir(char* sir, int l);