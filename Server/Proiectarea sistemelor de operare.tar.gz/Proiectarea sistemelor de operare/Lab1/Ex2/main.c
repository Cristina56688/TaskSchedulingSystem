#include <stdio.h>

void my_asm_func(int);
 
#define NAME "student"
#define NR (10)
 
int main()
{
  int i;
 
  // print the NAME NR times
    my_asm_func(2);
  for (i = 0; i < NR; i++)
    printf("Hello, %s\n", NAME);
 
  return 0;
}