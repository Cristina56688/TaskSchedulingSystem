#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/file.h> /* flock */
#include <fcntl.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h> /* errno */

#define LOCK_FILE "/tmp/my_lock_file"

static int fdlock = -1;

static void do_stuff(void)
{
	sleep(10);
}

static void check_lock(void)
{
	int rc;

	/* TODO - Open LOCK_FILE file */
	fdlock = open(LOCK_FILE, O_CREAT | O_RDWR, S_IRWXU); 

	/**
	 * TODO - Lock the file using flock
	 * - flock must not block in any case !
	 * 
	 *
	 * - in case of error - print a message showing
	 *   there is another instance running and exit
	 */

	 rc=flock(fdlock, LOCK_EX);
	 if(rc==-1)
	 {
		printf("There is another instance running.\n");
		exit(1);
	 }

	printf("\nGot Lock\n\n");
}

static void clean_up(void)
{
	int rc;
	/* TODO - Unlock file, close file and delete it */
	rc=flock(fdlock, F_UNLCK);   //nu e necesar unlock deoarece se da unlock automat la close
	if(rc==-1)
	{
		printf("The file can't be unlocked.\n");
		exit(1);
	}
	close(fdlock);
	unlink(LOCK_FILE);
}

int main(void)
{
	check_lock();
	do_stuff();
	clean_up();
	return 0;
}
