#include <stdio.h>
#include <stdlib.h>
 
#include <fcntl.h> /* open, O_RDWR, O_CREAT, O_TRUNC */
#include <unistd.h> /* dup2 */
 
int main(void) 
{
    int fd;
    int rc;
 
    fd = open("file", O_RDWR | O_CREAT | O_TRUNC);
    if (fd < 0) {
        perror("Error opening file");
        exit(-1);
    }
 
    rc = dup2(fd, 1);
    if (rc < 0) {
        perror("Error duplicating file descriptor");
        exit(-1);
    }
 

    char buf[20]="Hello world!\n";

    write(fd, buf, 13);
 
    rc = close(fd);
    if (rc < 0) {
        perror("Error closing file descriptor");
        exit(-1);
    }
 
    return 0;
} 