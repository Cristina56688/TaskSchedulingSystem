#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <string.h>

#define BUFFSIZE 25

int find_last_printable_character(const char *buf, size_t len) {
    int index = -1;
    for (size_t i = 0; i < len; i++) {
        unsigned char c = buf[i];
        if (c == '\n' || c == '\r' || c == '\t' || (c >= 32 && c <= 126)) 
			index=i;
    }
	if(index == -1) return 0;

    return index+1;
}

ssize_t full_read(int fd, void *buf, size_t count)
{
	ssize_t bytes=read(fd, buf, count);

	if(bytes==0)
		return bytes;



	if(bytes==count)
		{
			bytes=find_last_printable_character(buf, bytes);
			return bytes;
		}

	ssize_t more = full_read(fd, buf + bytes, count - bytes);
	
    if (more <= 0)
        {
			bytes=find_last_printable_character(buf, bytes);
			return bytes;
		}
	
	bytes=bytes=find_last_printable_character(buf, bytes+more);
    return bytes;
}

ssize_t full_write(int fd, void *buf, size_t count)
{
	if(count==0)
		return 0;

	ssize_t bytes=write(fd, buf, count);
	
	if(bytes==count)
		return bytes;

	bytes+=full_write(fd, buf+bytes, count-bytes);
	
	return bytes;
}

int main(int argc, char** argv, char** envp)
{
	if (argc < 3)
	{
		printf("Not enough arguments");
		exit(-1);
	}

	int fdin=open(argv[1], O_RDONLY);
	if(fdin < 0)
	{
		printf("Error opening %s.\n", argv[1]);
		exit(1);
	}

	int fdout=open(argv[2], O_TRUNC | O_CREAT | O_WRONLY, S_IRUSR);
	if(fdout < 0)
	{
		printf("Eerror opening %s.\n", argv[2]);
		exit(1);
	}

	char* buff=(char*)malloc(25*sizeof(char));
	if(buff==NULL)
	{
		printf("Error memory alocation.\n");
		exit(1);
	}

	ssize_t bytes;
	do
	{
		bytes=full_read(fdin, buff, BUFFSIZE);
		if(bytes>0)
		
		if(bytes>0)
			full_write(fdout, buff, bytes);
	
	}while(bytes>0);

	close(fdin);
	close(fdout);

	return 0;
}
